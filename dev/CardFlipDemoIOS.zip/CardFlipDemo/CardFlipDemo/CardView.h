#import <UIKit/UIKit.h>

@interface CardView : UIView

@property (assign, nonatomic, readonly) BOOL isFlipped;

- (id)initWithFrontImage:(UIImage *)frontImage backImage:(UIImage *)backImage;

@end
