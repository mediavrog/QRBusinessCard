
#import "MainViewController.h"
#import "CardView.h"

@interface MainViewController ()

- (void)addCardAtX:(CGFloat)x y:(CGFloat)y;

@end

@implementation MainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Add fou cards to the view
    [self addCardAtX:90 y:120];
    [self addCardAtX:230 y:120];
    [self addCardAtX:90 y:340];
    [self addCardAtX:230 y:340];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)addCardAtX:(CGFloat)x y:(CGFloat)y
{
    // Load images
    UIImage *img1 = [UIImage imageNamed:@"side1.png"];
    UIImage *img2= [UIImage imageNamed:@"side2.png"];
    
    // Create the view
    CardView *cv = [[CardView alloc] initWithFrontImage:img1 backImage:img2];   

    // Center card on location
    CGRect f = cv.frame;
    f.origin.x = x-(f.size.width/2.0);
    f.origin.y = y-(f.size.height/2.0);
    cv.frame = f;
    
    // Add card to view
    [self.view addSubview:cv];
}

@end
