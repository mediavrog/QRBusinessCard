
#import "CardView.h"
#import <QuartzCore/QuartzCore.h>

@interface CardView ()

@property (assign, nonatomic, readwrite) BOOL isFlipped;

@property (strong, nonatomic) UIImageView *frontView;
@property (strong, nonatomic) UIImageView *backView;

- (void)addSwipeRecognizerForDirection:(UISwipeGestureRecognizerDirection)direction;

- (void)flipCard:(UIViewAnimationOptions)options;

- (void)isTapped:(UITapGestureRecognizer *)recognizer;
- (void)isSwiped:(UISwipeGestureRecognizer *)recognizer;

@end

@implementation CardView

@synthesize isFlipped;
@synthesize frontView, backView;

- (id)initWithFrontImage:(UIImage *)frontImage backImage:(UIImage *)backImage 
{
    CGRect rect = CGRectMake(0, 0, frontImage.size.width, frontImage.size.height);
    
    self = [super initWithFrame:rect];
    if (self) {
        self.isFlipped = NO;
        self.backgroundColor = [UIColor clearColor];
        
        // Setip the front view
        self.frontView = [[UIImageView alloc] initWithImage:frontImage];        
        self.frontView.clipsToBounds = YES;
        self.frontView.layer.cornerRadius = 10.0;
        self.frontView.layer.borderWidth = 1.0;
        self.frontView.layer.borderColor = [[UIColor blackColor] CGColor];

        // Setip the back view
        self.backView = [[UIImageView alloc] initWithImage:backImage];
        self.backView.clipsToBounds = YES;
        self.backView.layer.cornerRadius = 10.0;
        self.backView.layer.borderWidth = 1.0;
        self.backView.layer.borderColor = [[UIColor blackColor] CGColor];

        // Add both views
        [self addSubview:self.frontView];
        [self addSubview:self.backView];
        
        // Add gesture recognizers
        [self addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(isTapped:)]];
        
        [self addSwipeRecognizerForDirection:UISwipeGestureRecognizerDirectionLeft];
        [self addSwipeRecognizerForDirection:UISwipeGestureRecognizerDirectionRight];
        if(IOS_VERSION_GREATER_THAN_OR_EQUAL_TO(@"5.0")) {
            [self addSwipeRecognizerForDirection:UISwipeGestureRecognizerDirectionUp];
            [self addSwipeRecognizerForDirection:UISwipeGestureRecognizerDirectionDown];        
        }
    }
    return self;
}

- (void)addSwipeRecognizerForDirection:(UISwipeGestureRecognizerDirection)direction
{
    // Create a swipe recognizer for the wanted direction
    UISwipeGestureRecognizer *swipeRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(isSwiped:)];
    swipeRecognizer.direction = direction;
    [self addGestureRecognizer:swipeRecognizer];
}

#pragma mark - Gesture recognizer handlers
- (void)isTapped:(UITapGestureRecognizer *)recognizer
{
    [self flipCard:UIViewAnimationOptionTransitionFlipFromLeft];
}

- (void)isSwiped:(UISwipeGestureRecognizer *)recognizer
{
    if (recognizer.direction == UISwipeGestureRecognizerDirectionLeft) {
        [self flipCard:UIViewAnimationOptionTransitionFlipFromRight];
    }
    else if (recognizer.direction == UISwipeGestureRecognizerDirectionRight) {
        [self flipCard:UIViewAnimationOptionTransitionFlipFromLeft];
    }
    else if (recognizer.direction == UISwipeGestureRecognizerDirectionUp) {
        [self flipCard:UIViewAnimationOptionTransitionFlipFromTop];
    }
    else if (recognizer.direction == UISwipeGestureRecognizerDirectionDown) {
        [self flipCard:UIViewAnimationOptionTransitionFlipFromBottom];
    }
}

#pragma mark - flip action
- (void)flipCard:(UIViewAnimationOptions)options
{
    if (self.isFlipped == NO) {
        [UIView transitionFromView:self.backView toView:self.frontView duration:0.4 options:options completion:NULL];
        self.isFlipped = YES;
    }
    else {
        [UIView transitionFromView:self.frontView toView:self.backView duration:0.4 options:options completion:NULL];
        self.isFlipped = NO;
    }
}

@end
